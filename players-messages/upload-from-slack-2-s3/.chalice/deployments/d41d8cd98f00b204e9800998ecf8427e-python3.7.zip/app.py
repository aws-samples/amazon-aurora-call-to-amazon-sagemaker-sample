from chalice import Chalice

app = Chalice(app_name='upload-from-slack-2-s3')


@app.route('/challenge', methods=['POST'])
def index():
    msg_as_json = app.current_request.json_body
    print('challengs request {}'.format(msg_as_json))
    return {'challenge' : msg_as_json['challenge']}


@app.route('/', methods=['POST'])
def index():
    msg_as_json = app.current_request.json_body
    if ('challenge' in msg_as_json):
      print('challengs request {}'.format(msg_as_json))
      return {'challenge' : msg_as_json['challenge']}
    else:
      print('going to publish {} to s3'.format(msg_as_json))
      return msg_as_json['elements']

# The view function above will return {"hello": "world"}
# whenever you make an HTTP GET request to '/'.
#
# Here are a few more examples:
#
# @app.route('/hello/{name}')
# def hello_name(name):
#    # '/hello/james' -> {"hello": "james"}
#    return {'hello': name}
#
@app.route('/message', methods=['POST'])
def post_msg_to_s3():
     # This is the JSON body the user sent in their POST request.
     msg_as_json = app.current_request.json_body
     # We'll echo the json body back to the user in a 'msg' key.
     return {'msg': msg_as_json}
#
# See the README documentation for more examples.
#
